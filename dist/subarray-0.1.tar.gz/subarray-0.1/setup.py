import setuptools

setuptools.setup(name='subarray',
      version='0.1',
      description='get 2D sub array slices from a large 2D array',
      author='Tasin Nawaz',
      author_email='tasin.buet@gmail.com',
      license='TN',
      url='',
      packages=setuptools.find_packages(),
      include_package_data=True,
      install_requires=[
      ],
      zip_safe=False)

