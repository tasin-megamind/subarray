# Sub Array

Returns sub array list from a larger array.

## Getting Started
python3 is needed for this package
```
pip install subarray
```

### Usage
```
from subarray import sub_array
# if m X n sub array is needed
results = sub_array(array, m, n)   
# array is the input array from which sub array is deduced. 
```
